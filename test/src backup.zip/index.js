import { MyFunction } from "./someFiles/module1";
import { MyClass } from "./someFiles/otherFiles/module2";

let instance1 = new MyFunction;
let instance2 = new MyClass;

instance1.MySubFunction();
instance2.MyFunction();